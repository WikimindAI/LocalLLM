@echo off
cd /d "%~dp0"
py -3 start.py || python start.py
pause
