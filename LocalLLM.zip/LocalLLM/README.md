# LocalLLM

Calculateur hors ligne : quels LLM ta machine peut faire tourner.

Lancer : `start.bat` (Windows) ou `sh start.sh` (macOS/Linux), puis http://localhost:8080
