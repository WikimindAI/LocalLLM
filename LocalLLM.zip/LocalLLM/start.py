import http.server, socketserver, webbrowser, os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
PORT = 8080
socketserver.TCPServer.allow_reuse_address = True
with socketserver.TCPServer(("127.0.0.1", PORT), http.server.SimpleHTTPRequestHandler) as s:
    url = f"http://localhost:{PORT}"
    print(f"LocalLLM sur {url}  (Ctrl+C pour arreter)")
    webbrowser.open(url)
    s.serve_forever()
